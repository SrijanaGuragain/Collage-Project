<?php

$conn = mysqli_connect('localhost','root','','project') or die('connection failed');

?>